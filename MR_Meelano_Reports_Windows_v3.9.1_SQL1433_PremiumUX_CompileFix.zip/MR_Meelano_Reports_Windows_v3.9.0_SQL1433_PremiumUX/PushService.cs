using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
namespace MReport.Windows;
public sealed class PushService : IDisposable
{
    readonly Uri? _endpoint; readonly CancellationTokenSource _cts=new(); ClientWebSocket? _socket;
    public event Action<string,string>? Notification;
    public PushService(string? endpoint){if(Uri.TryCreate(endpoint,UriKind.Absolute,out var u))_endpoint=u;}
    public async Task StartAsync(){if(_endpoint==null||(_endpoint.Scheme!="ws"&&_endpoint.Scheme!="wss"))return;_socket=new ClientWebSocket();try{await _socket.ConnectAsync(_endpoint,_cts.Token);var buf=new byte[8192];while(!_cts.IsCancellationRequested&&_socket.State==WebSocketState.Open){using var ms=new MemoryStream();WebSocketReceiveResult r;do{r=await _socket.ReceiveAsync(buf,_cts.Token);if(r.MessageType==WebSocketMessageType.Close)return;ms.Write(buf,0,r.Count);}while(!r.EndOfMessage);var text=Encoding.UTF8.GetString(ms.ToArray());try{using var d=JsonDocument.Parse(text);var root=d.RootElement;var title=root.TryGetProperty("title",out var t)?t.ToString():"M•REPORT";var body=root.TryGetProperty("body",out var b)?b.ToString():text;Notification?.Invoke(title,body);}catch{Notification?.Invoke("M•REPORT",text);}}}catch{}finally{_socket?.Dispose();}}
    public void Dispose(){_cts.Cancel();_socket?.Dispose();_cts.Dispose();}
}

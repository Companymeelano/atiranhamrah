using System.Windows;
using System.Windows.Media.Animation;
using System.Windows.Threading;
namespace MReport.Windows;
public partial class SplashWindow : Window
{
    readonly DispatcherTimer timer = new();
    public SplashWindow()
    {
        InitializeComponent();
        timer.Interval = TimeSpan.FromMilliseconds(2900);
        timer.Tick += (_, _) => { timer.Stop(); Close(); };
        Loaded += (_, _) =>
        {
            timer.Start();
            BeginStoryboard((System.Windows.Media.Animation.Storyboard)FindResource("Pulse"));
            var fade = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(650));
            BeginAnimation(OpacityProperty, fade);
        };
    }
}

#define MyAppName "M•R — Meelano Reports"
#define MyAppVersion "3.9.0"
#define MyAppPublisher "Meelano Studio Design"
#define MyAppExeName "MR.exe"
[Setup]
AppId={{D3A9E2F1-52B5-4E0A-9C2C-7B3A31003530}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL=https://meelano.ir
DefaultDirName={autopf}\Meelano\MR
DefaultGroupName=Meelano Reports
OutputDir=InstallerOutput
OutputBaseFilename=MR-Meelano-Reports-Setup-v3.9.0
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
WizardImageFile=Assets\installer_wizard.bmp
WizardSmallImageFile=Assets\installer_small.bmp
SetupIconFile=Assets\mreport.ico
UninstallDisplayIcon={app}\MR.exe
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=admin
DisableProgramGroupPage=yes
DisableWelcomePage=no
WizardSizePercent=105
DisableDirPage=no
DisableReadyPage=no
[Files]
Source: "bin\Release\net8.0-windows\win-x64\publish\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "mreport.settings.example.json"; DestDir: "{app}"; DestName: "mreport.settings.example.json"; Flags: ignoreversion
[Icons]
Name: "{group}\M•R — Meelano Reports"; Filename: "{app}\MR.exe"; IconFilename: "{app}\MR.exe"
Name: "{autodesktop}\M•R — Meelano Reports"; Filename: "{app}\MR.exe"; IconFilename: "{app}\MR.exe"; Tasks: desktopicon
[Tasks]
Name: "desktopicon"; Description: "ایجاد میانبر M•R روی Desktop"; GroupDescription: "میانبرها:"; Flags: checkedonce
[Run]
Filename: "{app}\MR.exe"; Description: "اجرای M•R — Meelano Reports"; Flags: nowait postinstall skipifsilent
[Code]
procedure CurPageChanged(CurPageID: Integer);
begin
  if CurPageID = wpWelcome then
  begin
    WizardForm.WelcomeLabel1.Caption := 'به M•R — Meelano Reports خوش آمدید';
    WizardForm.WelcomeLabel2.Caption := 'مرکز حرفه‌ای گزارش‌گیری و تحلیل مدیریتی آتیران' + #13#10 + 'خواندنی، سریع، امن و ساخته‌شده برای تصمیم‌گیری بهتر.';
  end;
end;

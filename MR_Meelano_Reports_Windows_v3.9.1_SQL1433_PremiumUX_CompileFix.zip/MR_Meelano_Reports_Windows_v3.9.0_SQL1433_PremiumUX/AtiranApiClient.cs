using System.Data;
using System.Text.Json;
using Microsoft.Data.SqlClient;

namespace MReport.Windows;

/// <summary>Direct, read-only Atiran SQL Server provider. Default tunnel/local port: 1433.</summary>
public sealed class AtiranApiClient : IAsyncDisposable
{
    private readonly SqlConnection _connection;
    private readonly string _database;
    public string Server { get; }
    public int Port { get; }
    public string Database => _database;
    public bool IsLocal { get; }

    public AtiranApiClient(string server, int port, string database, string? username = null, string? password = null, bool integratedSecurity = true)
    {
        Server = string.IsNullOrWhiteSpace(server) ? "localhost" : server.Trim();
        Port = port is >= 1 and <= 65535 ? port : 1433;
        _database = string.IsNullOrWhiteSpace(database) ? "Atiran2" : database.Trim();
        IsLocal = Server.Equals("localhost", StringComparison.OrdinalIgnoreCase) || Server.Equals("127.0.0.1") || Server.Equals(".");
        var cs = new SqlConnectionStringBuilder
        {
            DataSource = $"{Server},{Port}", InitialCatalog = _database,
            ConnectTimeout = 10, Encrypt = false,
            TrustServerCertificate = true, ApplicationName = "M•R Meelano Reports",
            Pooling = true, MaxPoolSize = 5
        };
        if (integratedSecurity || string.IsNullOrWhiteSpace(username)) cs.IntegratedSecurity = true;
        else { cs.UserID = username; cs.Password = password ?? string.Empty; }
        _connection = new SqlConnection(cs.ConnectionString);
    }

    public async Task TestConnectionAsync(CancellationToken cancellationToken = default)
    {
        await EnsureOpenAsync(cancellationToken);
        await using var cmd = new SqlCommand("SELECT DB_NAME(), @@SERVERNAME", _connection) { CommandTimeout = 10 };
        await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken)) throw new InvalidOperationException("SQL Server پاسخ قابل استفاده‌ای برنگرداند.");
        var db = reader.IsDBNull(0) ? "" : reader.GetString(0);
        if (!string.Equals(db, _database, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException($"اتصال برقرار شد اما دیتابیس «{db}» فعال است؛ دیتابیس انتخاب‌شده «{_database}» است.");
    }

    private async Task EnsureOpenAsync(CancellationToken cancellationToken = default)
    {
        if (_connection.State != ConnectionState.Open) await _connection.OpenAsync(cancellationToken);
    }

    private async Task<DataTable> QueryTableAsync(string sql, params SqlParameter[] parameters)
    {
        ValidateReadOnly(sql);
        await EnsureOpenAsync();
        await using var cmd = new SqlCommand(sql, _connection) { CommandTimeout = 45 };
        if (parameters.Length > 0) cmd.Parameters.AddRange(parameters);
        await using var reader = await cmd.ExecuteReaderAsync(CommandBehavior.SequentialAccess);
        var table = new DataTable(); table.Load(reader); return table;
    }

    private static void ValidateReadOnly(string sql)
    {
        var n = sql.Trim().TrimEnd(';').TrimStart().ToUpperInvariant();
        var forbidden = new[] { "INSERT ", "UPDATE ", "DELETE ", "MERGE ", "DROP ", "ALTER ", "TRUNCATE ", "EXEC ", "EXECUTE ", "CREATE ", "GRANT ", "REVOKE ", "BACKUP ", "RESTORE " };
        if (!(n.StartsWith("SELECT ") || n.StartsWith("WITH ")) || forbidden.Any(n.Contains))
            throw new InvalidOperationException("M•R فقط خواندنی است و این دستور اجازه اجرا ندارد.");
    }

    private static JsonElement ToJson(DataTable table)
    {
        using var stream = new MemoryStream();
        using (var writer = new Utf8JsonWriter(stream))
        {
            writer.WriteStartArray();
            foreach (DataRow row in table.Rows)
            {
                writer.WriteStartObject();
                foreach (DataColumn col in table.Columns)
                {
                    writer.WritePropertyName(col.ColumnName);
                    var value = row[col];
                    if (value == DBNull.Value || value is null) writer.WriteNullValue();
                    else if (value is byte[]) writer.WriteStringValue(Convert.ToBase64String((byte[])value));
                    else if (value is bool b) writer.WriteBooleanValue(b);
                    else if (value is DateTime dt) writer.WriteStringValue(dt.ToString("yyyy-MM-dd HH:mm:ss"));
                    else if (value is IFormattable f) writer.WriteStringValue(f.ToString(null, System.Globalization.CultureInfo.InvariantCulture));
                    else writer.WriteStringValue(value.ToString());
                }
                writer.WriteEndObject();
            }
            writer.WriteEndArray(); writer.Flush();
        }
        using var doc = JsonDocument.Parse(stream.ToArray()); return doc.RootElement.Clone();
    }

    private static SqlParameter P(string name, object value) => new(name, value ?? DBNull.Value);

    public async Task<JsonElement> Customers(int start = 0, int fetch = 250) => ToJson(await QueryTableAsync(
        "SELECT * FROM dbo.CUSTOMERS ORDER BY SHMO OFFSET @start ROWS FETCH NEXT @fetch ROWS ONLY", P("@start", Math.Max(0, start)), P("@fetch", Math.Clamp(fetch, 1, 5000))));

    public async Task<JsonElement> Kalas(int start = 0, int fetch = 250) => ToJson(await QueryTableAsync(
        "SELECT * FROM dbo.inventory ORDER BY SHKA OFFSET @start ROWS FETCH NEXT @fetch ROWS ONLY", P("@start", Math.Max(0, start)), P("@fetch", Math.Clamp(fetch, 1, 5000))));

    public Task<JsonElement> Inventory(int start = 0, int fetch = 250) => Kalas(start, fetch);

    public async Task<JsonElement> AllChecks() => ToJson(await QueryChecksAsync(0, 5000));
    public async Task<JsonElement> Checks(int start = 0, int fetch = 250) => ToJson(await QueryChecksAsync(start, fetch));

    private async Task<DataTable> QueryChecksAsync(int start, int fetch)
    {
        var table = await FindFirstTableAsync("checks", "check", "cheques", "cheque", "check_detail");
        if (table is null) return new DataTable();
        return await QueryTableAsync($"SELECT * FROM {QuoteName(table)} ORDER BY 1 OFFSET @start ROWS FETCH NEXT @fetch ROWS ONLY", P("@start", Math.Max(0, start)), P("@fetch", Math.Clamp(fetch, 1, 5000)));
    }

    public async Task<JsonElement> CustomerChecks(string shmo)
    {
        var table = await FindFirstTableAsync("checks", "check", "cheques", "cheque", "check_detail");
        if (table is null) return ToJson(new DataTable());
        return ToJson(await QueryTableAsync($"SELECT TOP (1000) * FROM {QuoteName(table)} WHERE SHMO=@shmo ORDER BY 1 DESC", P("@shmo", shmo)));
    }

    public async Task<JsonElement> CustomerFactors(string shmo) => ToJson(await QueryTableAsync("SELECT TOP (2000) * FROM dbo.sailfact WHERE SHMO=@shmo ORDER BY shfacfo DESC", P("@shmo", shmo)));
    public Task<JsonElement> Invoices(string shmo) => CustomerFactors(shmo);
    public Task<JsonElement> NotPaid(string shmo) => CustomerFactors(shmo);

    public async Task<JsonElement> KalaInventory(string shka) => ToJson(await QueryTableAsync("SELECT TOP (1000) * FROM dbo.inventory WHERE SHKA=@shka", P("@shka", shka)));
    public async Task<JsonElement> SaleLine(string sysid) => ToJson(await QueryTableAsync("SELECT TOP (5000) * FROM dbo.subsailfact WHERE shfacfo=@id ORDER BY 1", P("@id", sysid)));
    public async Task<JsonElement> CustomerActs(string shmo, DateTime from, DateTime to) => ToJson(await QueryTableAsync("SELECT TOP (5000) * FROM dbo.sailfact WHERE SHMO=@shmo AND date>=@from AND date<=@to ORDER BY date DESC", P("@shmo", shmo), P("@from", from), P("@to", to)));

    public async Task<JsonElement> CompanyInfo()
    {
        try { return ToJson(await QueryTableAsync("SELECT * FROM dbo.TBL_Func_CompanyName(1)")); }
        catch { return ToJson(await QueryTableAsync("SELECT TOP (1) * FROM dbo.CUSTOMERS")); }
    }

    public async Task<JsonElement> CountKa() => ScalarJson(await ScalarAsync("SELECT COUNT_BIG(1) FROM dbo.inventory"));
    public async Task<JsonElement> CountMo() => ScalarJson(await ScalarAsync("SELECT COUNT_BIG(1) FROM dbo.CUSTOMERS"));

    private async Task<long> ScalarAsync(string sql)
    {
        ValidateReadOnly(sql); await EnsureOpenAsync();
        await using var cmd = new SqlCommand(sql, _connection) { CommandTimeout = 20 };
        return Convert.ToInt64(await cmd.ExecuteScalarAsync());
    }
    private static JsonElement ScalarJson(long value)
    {
        using var doc = JsonDocument.Parse(value.ToString(System.Globalization.CultureInfo.InvariantCulture)); return doc.RootElement.Clone();
    }

    public async Task<JsonElement> QueryReadOnlyAsync(string sql) => ToJson(await QueryTableAsync(sql));

    private async Task<string?> FindFirstTableAsync(params string[] candidates)
    {
        var names = string.Join(",", candidates.Select(x => "'" + x.Replace("'", "''") + "'"));
        var sql = $"SELECT TOP (1) s.name + N'.' + t.name FROM sys.tables t JOIN sys.schemas s ON s.schema_id=t.schema_id WHERE t.name IN ({names}) ORDER BY CASE t.name WHEN 'checks' THEN 1 WHEN 'check' THEN 2 WHEN 'cheques' THEN 3 WHEN 'cheque' THEN 4 ELSE 99 END";
        ValidateReadOnly(sql); await EnsureOpenAsync();
        await using var cmd = new SqlCommand(sql, _connection);
        var value = await cmd.ExecuteScalarAsync(); return value?.ToString();
    }
    private static string QuoteName(string name) => string.Join('.', name.Split('.').Select(x => "[" + x.Replace("]", "]]" ) + "]"));

    public async ValueTask DisposeAsync() => await _connection.DisposeAsync();
}

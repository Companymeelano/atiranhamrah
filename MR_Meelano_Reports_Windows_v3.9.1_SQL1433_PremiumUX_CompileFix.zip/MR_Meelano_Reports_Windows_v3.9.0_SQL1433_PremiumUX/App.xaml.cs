using System.Windows;
using System.Windows.Threading;
namespace MReport.Windows;
public partial class App : System.Windows.Application
{
    private SplashWindow? _splash;
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        ShutdownMode = ShutdownMode.OnExplicitShutdown;
        DispatcherUnhandledException += App_DispatcherUnhandledException;
        _splash = new SplashWindow();
        _splash.Closed += Splash_Closed;
        _splash.Show();
    }
    private void Splash_Closed(object? sender, EventArgs e)
    {
        _splash = null;
        var login = new LoginWindow();
        MainWindow = login;
        login.Show();
        ShutdownMode = ShutdownMode.OnMainWindowClose;
    }
    private void App_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        MessageBox.Show("M•R در اجرای اولیه با یک خطای غیرمنتظره روبه‌رو شد.\n\n" + e.Exception.Message, "M•R — Meelano Reports", MessageBoxButton.OK, MessageBoxImage.Error);
        e.Handled = true;
    }
}

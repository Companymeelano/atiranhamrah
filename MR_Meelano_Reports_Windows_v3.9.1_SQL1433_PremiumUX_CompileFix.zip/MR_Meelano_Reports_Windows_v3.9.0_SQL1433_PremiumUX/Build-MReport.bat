@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build-MReport.ps1"
if errorlevel 1 (echo BUILD FAILED & pause & exit /b 1)
echo BUILD SUCCESSFUL
echo Next: open Installer.iss in Inno Setup 6 and compile it.
pause

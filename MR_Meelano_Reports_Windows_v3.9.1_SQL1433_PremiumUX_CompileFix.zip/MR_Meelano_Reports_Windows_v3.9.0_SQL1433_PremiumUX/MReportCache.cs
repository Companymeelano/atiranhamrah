using System.Collections.Concurrent;
using System.Text.Json;

namespace MReport.Windows;

public static class MReportCache
{
    static readonly ConcurrentDictionary<string,JsonElement> Cache=new();
    public static Task SetAsync(string key,JsonElement value){Cache[key]=value.Clone();return Task.CompletedTask;}
    public static bool TryGet(string key,out JsonElement value)=>Cache.TryGetValue(key,out value);
    public static void Clear()=>Cache.Clear();
}

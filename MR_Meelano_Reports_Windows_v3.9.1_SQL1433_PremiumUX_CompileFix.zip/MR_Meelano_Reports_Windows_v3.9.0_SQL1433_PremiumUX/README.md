# M•R — Meelano Reports 3.9.0 — SQL/Tunnel Edition

M•R is a Windows WPF read-only reporting client for Atiran SQL Server.

## Connection modes
- **Tunnel / Remote:** enter the server address and use TCP **1433** (default). The application connects directly to SQL Server; it does not treat 1433 as an HTTP/WCF service port.
- **Local:** select **اتصال Local** and the application uses `localhost,1433`. This is suitable when SQL Server is installed on the same Windows PC.
- **Windows Authentication:** recommended for local installations where the Windows account has read access to the Atiran database.
- **SQL Authentication:** uncheck Windows Authentication and enter the SQL login.

## Safety
The data provider is deliberately read-only. Application queries are restricted to SELECT/WITH statements and reject write/DDL/administrative commands. The M•R UI also exposes no insert, update or delete workflow.

## Database
Default database: `Atiran2`. Change it in the connection panel when the accounting database has another name.

## Atiran schema used by this edition
The provider uses the known Atiran tables/functions found in the project SQL/report artifacts, including `dbo.CUSTOMERS`, `dbo.inventory`, `dbo.sailfact`, `dbo.subsailfact` and `dbo.TBL_Func_CompanyName`. The checks area probes common Atiran check-table names before querying.

## Build
1. Open `MReport.Windows.sln` in Visual Studio 2022+.
2. Restore NuGet packages.
3. Build `MReport.Windows` for `win-x64`.
4. For the installer, build/publish first, then run `Installer.iss` with Inno Setup 6.

The execution environment used to prepare this source package does not contain the Windows .NET SDK/Inno Setup compiler, so this package is source/installer-ready rather than falsely claiming a compiled EXE was produced here.


## UX / Performance redesign — v3.9.0
- Login and splash completely redesigned with premium executive/cyber visual system.
- Added staged post-login warm-up screen with animated percentage progress.
- Only the first 60 rows of customers, goods, inventory and checks are warmed initially.
- Sections use DataGrid virtualization and explicit “load next 60” paging to prevent UI freezes.
- Tables now show both horizontal and vertical grid lines for clear row/column separation.
- Dashboard no longer pulls thousands of check rows at startup; it uses a small initial sample and lazy loads detail.
- Font stack upgraded to Segoe UI Variable Display/Text for a more polished Windows-native appearance.

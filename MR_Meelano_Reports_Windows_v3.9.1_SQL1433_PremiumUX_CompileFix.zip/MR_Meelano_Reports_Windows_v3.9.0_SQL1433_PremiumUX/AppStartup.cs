// Kept intentionally empty; startup is declared in App.xaml and project startup object is WPF default.

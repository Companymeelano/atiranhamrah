using System.IO;
using System.Windows;
using System.Windows.Input;

namespace MReport.Windows;

public partial class LoginWindow : Window
{
    const string DefaultServer = "37.143.147.19";
    const int DefaultPort = 1433;
    const string DefaultDatabase = "Atiran2";
    static string SettingsPath => Path.Combine(AppContext.BaseDirectory, "mreport.settings.json");

    public LoginWindow()
    {
        InitializeComponent(); WindowState = WindowState.Normal; LoadConnectionSettings();
        Loaded += (_, _) => SqlUsernameBox.Focus();
    }

    void LoadConnectionSettings()
    {
        ServerIpBox.Text = ReadSetting("Server") ?? DefaultServer;
        PortBox.Text = ReadSetting("Port") ?? DefaultPort.ToString();
        DatabaseBox.Text = ReadSetting("Database") ?? DefaultDatabase;
        SqlUsernameBox.Text = ReadSetting("SqlUsername") ?? "";
        SqlPasswordBox.Password = "";
        IntegratedCheck.IsChecked = !string.Equals(ReadSetting("IntegratedSecurity"), "false", StringComparison.OrdinalIgnoreCase);
        LocalCheck.IsChecked = string.Equals(ServerIpBox.Text, "localhost", StringComparison.OrdinalIgnoreCase) || ServerIpBox.Text == "127.0.0.1" || ServerIpBox.Text == ".";
        UpdatePreview();
    }

    void LocalCheck_Click(object sender, RoutedEventArgs e)
    {
        if (LocalCheck.IsChecked == true) ServerIpBox.Text = "localhost";
        else if (string.Equals(ServerIpBox.Text, "localhost", StringComparison.OrdinalIgnoreCase)) ServerIpBox.Text = DefaultServer;
        UpdatePreview();
    }
    void IntegratedCheck_Click(object sender, RoutedEventArgs e)
    {
        var integrated = IntegratedCheck.IsChecked == true; SqlUsernameBox.IsEnabled = !integrated; SqlPasswordBox.IsEnabled = !integrated;
    }
    void ConnectionChanged(object sender, System.Windows.Controls.TextChangedEventArgs e) => UpdatePreview();
    void UpdatePreview()
    {
        var server = string.IsNullOrWhiteSpace(ServerIpBox.Text) ? DefaultServer : ServerIpBox.Text.Trim();
        var port = int.TryParse(PortBox.Text, out var p) && p is >= 1 and <= 65535 ? p : DefaultPort;
        EndpointPreview.Text = $"SQL Server  •  {server},{port}  •  {DatabaseBox.Text.Trim()}";
        ModeText.Text = LocalCheck.IsChecked == true ? "LOCAL SQL" : "TUNNEL / REMOTE SQL";
    }
    void SaveConnection_Click(object sender, RoutedEventArgs e)
    {
        SaveSetting("Server", ServerIpBox.Text.Trim()); SaveSetting("Port", PortBox.Text.Trim()); SaveSetting("Database", DatabaseBox.Text.Trim());
        SaveSetting("SqlUsername", SqlUsernameBox.Text.Trim()); SaveSetting("IntegratedSecurity", (IntegratedCheck.IsChecked == true).ToString());
        ErrorText.Foreground = System.Windows.Media.Brushes.LightGreen; ErrorText.Text = "تنظیمات اتصال SQL ذخیره شد.";
    }
    async void Login_Click(object sender, RoutedEventArgs e) => await Connect(false);
    async void Demo_Click(object sender, RoutedEventArgs e) { var main = new MainWindow(null, "Demo", null); Application.Current.MainWindow = main; main.Show(); Close(); }
    void Clear_Click(object sender, RoutedEventArgs e) { SqlUsernameBox.Text = ""; SqlPasswordBox.Password = ""; ErrorText.Text = ""; }
    async void TestConnection_Click(object sender, RoutedEventArgs e) => await Connect(true);

    async Task Connect(bool testOnly)
    {
        ErrorText.Foreground = System.Windows.Media.Brushes.OrangeRed; ErrorText.Text = "در حال اتصال مستقیم به SQL Server…";
        LoginButton.IsEnabled = false; TestButton.IsEnabled = false;
        try
        {
            var server = string.IsNullOrWhiteSpace(ServerIpBox.Text) ? DefaultServer : ServerIpBox.Text.Trim();
            var port = int.TryParse(PortBox.Text, out var p) && p is >= 1 and <= 65535 ? p : DefaultPort;
            var db = string.IsNullOrWhiteSpace(DatabaseBox.Text) ? DefaultDatabase : DatabaseBox.Text.Trim();
            var integrated = IntegratedCheck.IsChecked == true;
            var api = new AtiranApiClient(server, port, db, SqlUsernameBox.Text.Trim(), SqlPasswordBox.Password, integrated);
            await api.TestConnectionAsync();
            SaveConnection_Click(null!, null!);
            ErrorText.Foreground = System.Windows.Media.Brushes.LightGreen; ErrorText.Text = $"✓ اتصال موفق • {server},{port} • {db}";
            if (!testOnly)
            {
                MReportCache.Clear();
                var loader = new LoadingWindow { Owner = this };
                loader.Show();
                try
                {
                    Hide();
                    await loader.WarmUpAsync(api);
                    var main = new MainWindow(api, integrated ? Environment.UserName : SqlUsernameBox.Text.Trim(), null);
                    Application.Current.MainWindow = main; main.WindowState = WindowState.Normal; main.Show();
                    loader.Close(); Close();
                }
                catch
                {
                    loader.Close(); Show(); throw;
                }
            }
            else await api.DisposeAsync();
        }
        catch (Exception ex)
        {
            ErrorText.Text = "اتصال برقرار نشد: " + ex.Message;
        }
        finally { LoginButton.IsEnabled = true; TestButton.IsEnabled = true; }
    }
    void Window_Drag(object? s, MouseButtonEventArgs e) { if (e.LeftButton == MouseButtonState.Pressed) DragMove(); }
    void Minimize_Click(object? s, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    void Maximize_Click(object? s, RoutedEventArgs e) => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
    void Close_Click(object? s, RoutedEventArgs e) => Close();
    async void Password_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) await Connect(false); }
    static string? ReadSetting(string key) { try { if (!File.Exists(SettingsPath)) return null; using var d = System.Text.Json.JsonDocument.Parse(File.ReadAllText(SettingsPath)); return d.RootElement.TryGetProperty(key, out var v) ? v.ToString() : null; } catch { return null; } }
    static void SaveSetting(string key, string value) { try { var data = new Dictionary<string, string>(); if (File.Exists(SettingsPath)) using (var d = System.Text.Json.JsonDocument.Parse(File.ReadAllText(SettingsPath))) foreach (var x in d.RootElement.EnumerateObject()) data[x.Name] = x.Value.ToString(); data[key] = value; File.WriteAllText(SettingsPath, System.Text.Json.JsonSerializer.Serialize(data, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })); } catch { } }
}

using System.Data;
using System.Windows.Documents;
using System.Windows.Controls.Primitives;
using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Forms = System.Windows.Forms;

namespace MReport.Windows;

public partial class MainWindow : Window
{
    readonly AtiranApiClient api; readonly string? shmo; readonly Forms.NotifyIcon tray; readonly System.Windows.Threading.DispatcherTimer alertTimer; readonly PushService push;
    DataTable? currentReport; string currentSection="Dashboard"; string currentTheme="Obsidian"; readonly Dictionary<string,Button> navButtons=new();
    public MainWindow(AtiranApiClient api,string? customer,string? shmo)
    {
        InitializeComponent(); WindowState=WindowState.Normal; Width=1180; Height=720; ResizeMode=ResizeMode.CanResize; this.api=api; this.shmo=shmo;
        tray=new Forms.NotifyIcon{Icon=CreateTrayIcon(),Visible=true,Text="M•R"};
        tray.DoubleClick+=(s,e)=>{Show();WindowState=WindowState.Normal;Activate();};
        ConnectionText.Text = $"SQL • {(api.IsLocal ? "LOCAL" : "TUNNEL")} • {api.Server}:{api.Port} • {api.Database} • READ ONLY";
        push=new PushService(ReadSetting("PushGatewayUrl")); push.Notification+=(t,b)=>Dispatcher.Invoke(()=>Notify(t,b)); _=push.StartAsync();
        alertTimer=new System.Windows.Threading.DispatcherTimer{Interval=TimeSpan.FromMinutes(5)}; alertTimer.Tick+=async(s,e)=>await PollAlerts(); alertTimer.Start();
        Loaded+=async(s,e)=>{IndexNavigation();SetActive("Dashboard");await ShowDashboard();}; KeyDown+=Main_KeyDown;
        Closed+=(s,e)=>{alertTimer.Stop();push.Dispose();tray.Visible=false;tray.Dispose();_ = api.DisposeAsync();};
    }
    void Main_KeyDown(object? sender,KeyEventArgs e){if(e.Key==Key.K&&(Keyboard.Modifiers&ModifierKeys.Control)==ModifierKeys.Control){e.Handled=true;Command_Click(null!,null!);}}
    void Window_Drag(object? s,MouseButtonEventArgs e){if(e.LeftButton==MouseButtonState.Pressed)DragMove();}
    void Minimize_Click(object? s,RoutedEventArgs e){WindowState=WindowState.Minimized;}
    void Maximize_Click(object? s,RoutedEventArgs e){WindowState=WindowState==WindowState.Maximized?WindowState.Normal:WindowState.Maximized;}
    void Close_Click(object? s,RoutedEventArgs e){Close();}

    void Command_Click(object? s,RoutedEventArgs? e){var w=new Window{Title="Command Palette — M•R",Width=560,Height=400,WindowStartupLocation=WindowStartupLocation.CenterOwner,Owner=this,Background=(Brush)FindResource("Bg"),FlowDirection=FlowDirection.RightToLeft};var p=new StackPanel{Margin=new Thickness(24)};p.Children.Add(new TextBlock{Text="جستجوی سریع",FontSize=24,FontWeight=FontWeights.Bold,Foreground=Brush("Text")});var tb=new TextBox{Margin=new Thickness(0,18,0,12),Height=42};p.Children.Add(tb);var list=new ListBox{Background=Brush("Panel"),Foreground=Brush("Text")};foreach(var x in new[]{"داشبورد","مشتریان 360°","کالاها","هشدارها","اعلان‌ها","Report Studio","تنظیمات"})list.Items.Add(x);list.MouseDoubleClick+=(a,b)=>{var t=list.SelectedItem?.ToString();w.Close();if(t=="داشبورد")_=ShowDashboard();else if(t=="مشتریان 360°")_=ShowCustomers();else if(t=="کالاها")_=ShowGoods();else if(t=="هشدارها")_=ShowAlerts();else if(t=="اعلان‌ها")ShowNotifications();else if(t=="Report Studio")ShowReportBuilder();else if(t=="تنظیمات")ShowSettings();};p.Children.Add(list);tb.TextChanged+=(a,b)=>{var q=tb.Text.Trim();list.Items.Clear();foreach(var x in new[]{"داشبورد","مشتریان 360°","کالاها","هشدارها","اعلان‌ها","Report Studio","تنظیمات"}.Where(x=>x.Contains(q,StringComparison.OrdinalIgnoreCase)))list.Items.Add(x);};w.Content=p;w.ShowDialog();}
    void IndexNavigation(){ foreach(var b in FindVisualChildren<Button>(this)){ if(b.Tag is string tag) navButtons[tag]=b; } }
    static IEnumerable<T> FindVisualChildren<T>(DependencyObject d) where T:DependencyObject { if(d==null) yield break; for(int i=0;i<VisualTreeHelper.GetChildrenCount(d);i++){var c=VisualTreeHelper.GetChild(d,i); if(c is T t) yield return t; foreach(var x in FindVisualChildren<T>(c)) yield return x;} }
    void SetActive(string tag){ foreach(var kv in navButtons){kv.Value.Opacity=kv.Key==tag?1.0:.72; if(kv.Key==tag) kv.Value.BorderBrush=Brush("Accent2"); else kv.Value.BorderBrush=Brush("Line");} }
    async void Nav_Click(object s,RoutedEventArgs e){try{var tag=(s as Button)?.Tag?.ToString()??"Dashboard";SetActive(tag);currentSection=tag;switch(tag){case"Dashboard":await ShowDashboard();break;case"Customers":await ShowCustomers();break;case"Goods":await ShowGoods();break;case"Inventory":await ShowInventory();break;case"Invoices":await ShowInvoices();break;case"Checks":await ShowChecks();break;case"Alerts":await ShowAlerts();break;case"Notifications":ShowNotifications();break;case"ReportBuilder":ShowReportBuilder();break;case"Company":await ShowCompany();break;case"Settings":ShowSettings();break;}}catch(Exception ex){ShowError(ex);}}
    async Task ShowDashboard()
    {
        currentSection="Dashboard";
        var root=Page("مرکز فرمان M•R","Executive Command Center • تصویر زنده، خوانا و بدون داده ساختگی از سرویس آتیران");

        JsonElement ka=default, mo=default, checks=default, unpaid=default;
        try { ka=await api.CountKa(); } catch { }
        try { mo=await api.CountMo(); } catch { }
        try { checks=await api.Checks(0,60); } catch { }
        if(!string.IsNullOrWhiteSpace(shmo)) try { unpaid=await api.NotPaid(shmo!); } catch { }

        int checkCount=ArrayCount(checks), unpaidCount=ArrayCount(unpaid);
        int overdue=CountOverdue(checks);
        decimal unpaidAmount=MoneySum(unpaid,"AllFel","MabDaryaftFactor","Tdf");

        var hero=new Border{Background=Brush("Panel"),BorderBrush=Brush("Line"),BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(26),Padding=new Thickness(24),Margin=new Thickness(0,14,0,16)};
        var hg=new Grid(); hg.ColumnDefinitions.Add(new ColumnDefinition()); hg.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(300)});
        var hp=new StackPanel();
        hp.Children.Add(new TextBlock{Text="M•R  /  EXECUTIVE PULSE",FontSize=11,FontWeight=FontWeights.SemiBold,Foreground=Brush("Accent2")});
        hp.Children.Add(new TextBlock{Text="داده را فقط نمی‌بینید؛ وضعیت کسب‌وکار را می‌خوانید.",FontSize=25,FontWeight=FontWeights.Bold,Foreground=Brush("Text"),Margin=new Thickness(0,7,0,5)});
        hp.Children.Add(new TextBlock{Text="نمایش کاملاً Read Only؛ تمام شاخص‌های زیر از داده‌های واقعی سرویس آتیران در همین نشست محاسبه شده‌اند.",FontSize=12,Foreground=Brush("Muted"),TextWrapping=TextWrapping.Wrap});
        var pulse=new WrapPanel{Margin=new Thickness(0,18,0,0)};
        pulse.Children.Add(Pill("● LIVE DATA", "Success")); pulse.Children.Add(Pill("◈ READ ONLY", "Accent")); pulse.Children.Add(Pill("↻ AUTO MONITOR", "Accent2"));
        hp.Children.Add(pulse); Grid.SetColumn(hp,0); hg.Children.Add(hp);
        var orb=new Border{Background=Brush("Panel2"),CornerRadius=new CornerRadius(22),Padding=new Thickness(18),Margin=new Thickness(20,0,0,0)};
        var op=new StackPanel{HorizontalAlignment=HorizontalAlignment.Center};
        op.Children.Add(new TextBlock{Text="M•R",FontSize=34,FontWeight=FontWeights.Bold,Foreground=Brush("Text"),HorizontalAlignment=HorizontalAlignment.Center});
        op.Children.Add(new TextBlock{Text="INTELLIGENCE CORE",FontSize=9,Foreground=Brush("Accent2"),HorizontalAlignment=HorizontalAlignment.Center});
        op.Children.Add(new TextBlock{Text=$"{DateTime.Now:HH:mm:ss}",FontSize=22,FontWeight=FontWeights.SemiBold,Foreground=Brush("Text"),HorizontalAlignment=HorizontalAlignment.Center,Margin=new Thickness(0,12,0,0)});
        op.Children.Add(new TextBlock{Text="آخرین بارگذاری رابط",FontSize=10,Foreground=Brush("Muted"),HorizontalAlignment=HorizontalAlignment.Center}); orb.Child=op; Grid.SetColumn(orb,1); hg.Children.Add(orb);
        hero.Child=hg; root.Children.Add(hero);

        var cards=new UniformGrid{Columns=4,Margin=new Thickness(-5,0,-5,12)};
        cards.Children.Add(Metric("کالاها",Scalar(ka),"▣","#A78BFA"));
        cards.Children.Add(Metric("مشتریان",Scalar(mo),"♙","#67E8F9"));
        cards.Children.Add(Metric("چک‌ها",checkCount.ToString("N0"),"◍","#D8B36A"));
        cards.Children.Add(Metric("مطالبات جاری",unpaidAmount==0m?"—":unpaidAmount.ToString("N0"),"₿","#70E0A7"));
        root.Children.Add(cards);

        var main=new Grid{Margin=new Thickness(0,4,0,0)};
        main.ColumnDefinitions.Add(new ColumnDefinition()); main.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(360)});
        var intelligence=Glass("Business Signal Map"); var ip=(StackPanel)intelligence.Child;
        ip.Children.Add(new TextBlock{Text="سیگنال‌های واقعی نشست فعلی",FontSize=19,FontWeight=FontWeights.Bold,Foreground=Brush("Text"),Margin=new Thickness(0,0,0,5)});
        ip.Children.Add(new TextBlock{Text="بدون نمودارهای تزئینی یا درصدهای ساختگی؛ فقط شاخص‌هایی که از پاسخ سرویس قابل استخراج‌اند.",Foreground=Brush("Muted"),FontSize=11,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,14)});
        ip.Children.Add(SignalBar("چک‌های ثبت‌شده",checkCount,Math.Max(1,checkCount),"Accent2"));
        ip.Children.Add(SignalBar("سررسید گذشته",overdue,Math.Max(1,checkCount),"Danger"));
        ip.Children.Add(SignalBar("فاکتورهای پرداخت‌نشده",unpaidCount,Math.Max(1,unpaidCount),"Accent"));
        ip.Children.Add(SignalBar("حالت امنیتی",1,1,"Success"));
        ip.Children.Add(new Border{Background=Brush("Panel2"),CornerRadius=new CornerRadius(16),Padding=new Thickness(14),Margin=new Thickness(0,15,0,0),Child=new TextBlock{Text="نکته مدیریتی\nاگر مقدار «—» نمایش داده شود، یعنی آن شاخص برای نشست فعلی یا سرویس در دسترس نبوده است؛ M•R هرگز عدد حدسی جایگزین نمی‌کند.",Foreground=Brush("Muted"),FontSize=11,TextWrapping=TextWrapping.Wrap}});
        Grid.SetColumn(intelligence,0); main.Children.Add(intelligence);

        var side=Glass("Focus Mode"); var sp=(StackPanel)side.Child;
        sp.Children.Add(new TextBlock{Text="سه نگاه سریع",FontSize=17,FontWeight=FontWeights.Bold,Foreground=Brush("Text")});
        AddFocus(sp,"01","Customers 360°","پرونده مشتری، گردش حساب و چک‌ها");
        AddFocus(sp,"02","Inventory","تصویر موجودی و انبارها");
        AddFocus(sp,"03","Smart Alerts","اولویت‌بندی موارد نیازمند توجه");
        sp.Children.Add(new Separator{Margin=new Thickness(0,12,0,12),Background=Brush("Line")});
        sp.Children.Add(new TextBlock{Text="SESSION STATUS",FontSize=9,Foreground=Brush("Muted")});
        sp.Children.Add(StatusLine("Data Source","ATIRAN SQL / 1433")); sp.Children.Add(StatusLine("Write Access","DISABLED"));
        Grid.SetColumn(side,1); main.Children.Add(side);
        root.Children.Add(main);

        var radar=Glass("M•R Intelligence Radar");
        var rg=new Grid{Margin=new Thickness(0,2,0,0)};
        rg.ColumnDefinitions.Add(new ColumnDefinition()); rg.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(330)});
        var rp=new StackPanel();
        rp.Children.Add(new TextBlock{Text="مقایسه نسبی شاخص‌های قابل مشاهده در این نشست",Foreground=Brush("Muted"),FontSize=11,Margin=new Thickness(0,0,0,12)});
        var maxMetric=Math.Max(1,Math.Max(Math.Max(checkCount,unpaidCount),Math.Max(ParseInt(Scalar(ka)),ParseInt(Scalar(mo)))));
        rp.Children.Add(ChartBar("کالاها",ParseInt(Scalar(ka)),maxMetric,"Accent"));
        rp.Children.Add(ChartBar("مشتریان",ParseInt(Scalar(mo)),maxMetric,"Accent2"));
        rp.Children.Add(ChartBar("چک‌ها",checkCount,maxMetric,"Success"));
        rp.Children.Add(ChartBar("فاکتورهای باز",unpaidCount,maxMetric,"Danger"));
        Grid.SetColumn(rp,0); rg.Children.Add(rp);
        var quality=new Border{Background=Brush("Panel2"),CornerRadius=new CornerRadius(18),Padding=new Thickness(18),Margin=new Thickness(18,0,0,0)};
        var qp2=new StackPanel(); qp2.Children.Add(new TextBlock{Text="DATA QUALITY",FontSize=9,Foreground=Brush("Accent2")});
        qp2.Children.Add(new TextBlock{Text="READ-ONLY INTEGRITY",FontSize=18,FontWeight=FontWeights.Bold,Foreground=Brush("Text"),Margin=new Thickness(0,6,0,10)});
        qp2.Children.Add(new TextBlock{Text="✓ بدون INSERT / UPDATE / DELETE",Foreground=Brush("Success"),FontSize=11,Margin=new Thickness(0,3,0,0)});
        qp2.Children.Add(new TextBlock{Text="✓ داده‌ها از سرویس مجاز آتیران",Foreground=Brush("Success"),FontSize=11,Margin=new Thickness(0,5,0,0)});
        qp2.Children.Add(new TextBlock{Text="✓ بدون اتصال مستقیم به SQL",Foreground=Brush("Success"),FontSize=11,Margin=new Thickness(0,5,0,0)});
        qp2.Children.Add(new TextBlock{Text="وضعیت: پایدار",Foreground=Brush("Muted"),FontSize=10,Margin=new Thickness(0,14,0,0)}); quality.Child=qp2; Grid.SetColumn(quality,1); rg.Children.Add(quality);
        radar.Child=rg; root.Children.Add(radar);

        var quick=Glass("Quick Launch"); var qp=(StackPanel)quick.Child; var qwrap=new WrapPanel();
        foreach(var item in new[]{("◌  مشتریان 360°",(Func<Task>)(()=>ShowCustomers())),("▦  موجودی",(Func<Task>)(()=>ShowInventory())),("△  هشدارها",(Func<Task>)(()=>ShowAlerts())),("✧  Report Studio",(Func<Task>)(()=>{ShowReportBuilder();return Task.CompletedTask;}))}){var b=new Button{Content=item.Item1,MinWidth=190,Height=44};b.Click+=async(s,e)=>await item.Item2();qwrap.Children.Add(b);} qp.Children.Add(qwrap); root.Children.Add(quick);
        AddFooter(root); ContentHost.Children.Add(root);
    }

    Border Pill(string text,string key){return new Border{Background=Brush("Panel2"),BorderBrush=Brush(key),BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(14),Padding=new Thickness(10,6,10,6),Margin=new Thickness(0,0,7,0),Child=new TextBlock{Text=text,Foreground=Brush(key),FontSize=9,FontWeight=FontWeights.SemiBold}};}
    Border SignalBar(string label,int value,int max,string accentKey){double ratio=max<=0?0:Math.Clamp((double)value/max,0,1);var b=new Border{Background=Brush("Panel2"),CornerRadius=new CornerRadius(15),Padding=new Thickness(13),Margin=new Thickness(0,0,0,9)};var p=new StackPanel();var g=new Grid();g.ColumnDefinitions.Add(new ColumnDefinition());g.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});g.Children.Add(new TextBlock{Text=label,Foreground=Brush("Text")});var v=new TextBlock{Text=value.ToString("N0"),Foreground=Brush(accentKey),FontWeight=FontWeights.Bold};Grid.SetColumn(v,1);g.Children.Add(v);p.Children.Add(g);var track=new Border{Height=6,Background=Brush("Line"),CornerRadius=new CornerRadius(3),Margin=new Thickness(0,9,0,0)};var fill=new Border{Height=6,Width=Math.Max(4,ratio*300),Background=Brush(accentKey),CornerRadius=new CornerRadius(3),HorizontalAlignment=HorizontalAlignment.Left};track.Child=fill;p.Children.Add(track);b.Child=p;return b;}
    Border ChartBar(string label,int value,int max,string accentKey){double ratio=max<=0?0:Math.Clamp((double)value/max,0,1);var wrap=new StackPanel{Margin=new Thickness(0,0,0,10)};var g=new Grid();g.ColumnDefinitions.Add(new ColumnDefinition());g.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});g.Children.Add(new TextBlock{Text=label,Foreground=Brush("Text"),FontSize=11});var v=new TextBlock{Text=value.ToString("N0"),Foreground=Brush(accentKey),FontWeight=FontWeights.Bold,FontSize=11};Grid.SetColumn(v,1);g.Children.Add(v);wrap.Children.Add(g);var track=new Border{Height=8,Background=Brush("Line"),CornerRadius=new CornerRadius(4),Margin=new Thickness(0,6,0,0)};track.Child=new Border{Height=8,Width=Math.Max(3,300*ratio),Background=Brush(accentKey),CornerRadius=new CornerRadius(4),HorizontalAlignment=HorizontalAlignment.Left};wrap.Children.Add(track);return new Border{Child=wrap};}
    int ParseInt(string s){var digits=new string((s??"").Where(char.IsDigit).ToArray());return int.TryParse(digits,NumberStyles.Any,CultureInfo.InvariantCulture,out var n)?n:0;}

    void AddFocus(StackPanel p,string no,string title,string sub){var b=new Button{HorizontalContentAlignment=HorizontalAlignment.Right,Padding=new Thickness(12),Margin=new Thickness(0,7,0,0)};var g=new Grid();g.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});g.ColumnDefinitions.Add(new ColumnDefinition());var n=new TextBlock{Text=no,Foreground=Brush("Accent2"),FontWeight=FontWeights.Bold,Margin=new Thickness(0,0,12,0)};g.Children.Add(n);var s=new StackPanel();s.Children.Add(new TextBlock{Text=title,Foreground=Brush("Text"),FontWeight=FontWeights.SemiBold});s.Children.Add(new TextBlock{Text=sub,Foreground=Brush("Muted"),FontSize=10,Margin=new Thickness(0,3,0,0)});Grid.SetColumn(s,1);g.Children.Add(s);b.Content=g;p.Children.Add(b);}

    async Task<JsonElement> GetCachedOrLoad(string key, Func<Task<JsonElement>> loader)
    {
        if (MReportCache.TryGet(key, out var cached)) return cached;
        var data = await loader();
        await MReportCache.SetAsync(key, data);
        return data;
    }

    async Task ShowCustomers()
    {
        currentSection="Customers"; SetActive("Customers");var root=Page("مشتریان 360°","جستجوی مستقل + مشاهده گردش حساب، فاکتورها و چک‌های هر مشتری");var bar=new StackPanel{Orientation=Orientation.Horizontal};var search=new TextBox{Width=360,Height=40};search.SetValue(FrameworkElement.ToolTipProperty,"نام، شماره مشتری، موبایل یا تلفن");bar.Children.Add(search);var status=new TextBlock{Foreground=Brush("Muted"),VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(10,0,0,8)};bar.Children.Add(status);root.Children.Add(bar);
        var grid=DataGridFor();root.Children.Add(grid);var more=new Button{Content="＋  بارگذاری ۶۰ مشتری بعدی",HorizontalAlignment=HorizontalAlignment.Left,Padding=new Thickness(18,10,18,10),Margin=new Thickness(0,0,0,12)};root.Children.Add(more);var detail=Glass("Customer 360°");root.Children.Add(detail);ContentHost.Children.Add(root);
        var data=await GetCachedOrLoad("customers", () => api.Customers(0,60));var table=ToTable(data);grid.ItemsSource=table.DefaultView;status.Text=$"{table.Rows.Count:N0} مشتری آماده";more.Click+=async(s,e)=>{try{more.IsEnabled=false;var next=ToTable(await api.Customers(table.Rows.Count,60));AppendTable(table,next);status.Text=$"{table.Rows.Count:N0} مشتری آماده";}catch(Exception ex){ShowError(ex);}finally{more.IsEnabled=true;}};
        search.TextChanged+=(s,e)=>{var q=search.Text.Replace("'","''");table.DefaultView.RowFilter=string.IsNullOrWhiteSpace(q)?"":string.Join(" OR ",table.Columns.Cast<DataColumn>().Where(c=>c.DataType==typeof(string)).Select(c=>$"[{c.ColumnName}] LIKE '%{q}%'").DefaultIfEmpty("1=0"));status.Text=$"{table.DefaultView.Count:N0} نتیجه";};
        grid.SelectionChanged+=async(s,e)=>{if(grid.SelectedItem is DataRowView rv){await RenderCustomer360(detail,rv.Row);}};
    }
    async Task RenderCustomer360(Border host,DataRow row)
    {
        var sh=GetRow(row,"Shmo","shmo","SHMO");var p=host.Child as StackPanel ?? new StackPanel();host.Child=p;p.Children.Add(new TextBlock{Text=$"پرونده مشتری  •  {GetRow(row,"Moname","Name","MONAME")}",FontSize=18,FontWeight=FontWeights.Bold,Foreground=Brush("Text")});p.Children.Add(new TextBlock{Text=$"کد: {sh}   |   موبایل: {GetRow(row,"Cell","CELL")}",Foreground=Brush("Muted"),Margin=new Thickness(0,4,0,12)});var tabs=new TabControl{Background=Brush("Panel")};var acts=new TabItem{Header="گردش حساب"};var inv=new TabItem{Header="فاکتورها"};var ch=new TabItem{Header="چک‌ها"};tabs.Items.Add(acts);tabs.Items.Add(inv);tabs.Items.Add(ch);p.Children.Add(tabs);
        if(!string.IsNullOrWhiteSpace(sh)){try{acts.Content=BuildTable(await api.CustomerActs(sh!,new DateTime(1900,1,1),new DateTime(2999,12,29)));inv.Content=BuildTable(await api.Invoices(sh!));ch.Content=BuildTable(await api.CustomerChecks(sh!));}catch(Exception ex){acts.Content=new TextBlock{Text="دریافت جزئیات انجام نشد: "+ex.Message,Foreground=Brush("Danger"),Margin=new Thickness(12)};}}
    }
    async Task ShowGoods()
    {
        currentSection="Goods"; SetActive("Goods");var root=Page("کالاها","جستجوی مستقل کالا + مشاهده وضعیت موجودی واقعی");var bar=new StackPanel{Orientation=Orientation.Horizontal};var search=new TextBox{Width=360,Height=40};bar.Children.Add(search);var status=new TextBlock{Foreground=Brush("Muted"),VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(10,0,0,8)};bar.Children.Add(status);root.Children.Add(bar);var grid=DataGridFor();root.Children.Add(grid);var more=new Button{Content="＋  بارگذاری ۶۰ کالای بعدی",HorizontalAlignment=HorizontalAlignment.Left,Padding=new Thickness(18,10,18,10),Margin=new Thickness(0,0,0,12)};root.Children.Add(more);var detail=Glass("گردش / موجودی کالا");root.Children.Add(detail);ContentHost.Children.Add(root);var data=await GetCachedOrLoad("goods", () => api.Kalas(0,60));var table=ToTable(data);grid.ItemsSource=table.DefaultView;status.Text=$"{table.Rows.Count:N0} کالا آماده";more.Click+=async(s,e)=>{try{more.IsEnabled=false;var next=ToTable(await api.Kalas(table.Rows.Count,60));AppendTable(table,next);status.Text=$"{table.Rows.Count:N0} کالا آماده";}catch(Exception ex){ShowError(ex);}finally{more.IsEnabled=true;}};search.TextChanged+=(s,e)=>{var q=search.Text.Replace("'","''");table.DefaultView.RowFilter=string.IsNullOrWhiteSpace(q)?"":string.Join(" OR ",table.Columns.Cast<DataColumn>().Where(c=>c.DataType==typeof(string)).Select(c=>$"[{c.ColumnName}] LIKE '%{q}%'").DefaultIfEmpty("1=0"));};grid.SelectionChanged+=async(s,e)=>{if(grid.SelectedItem is DataRowView rv){var sh=GetRow(rv.Row,"Shka","shka","SHKA");if(!string.IsNullOrWhiteSpace(sh))try{detail.Child=BuildTable(await api.KalaInventory(sh!));}catch(Exception ex){detail.Child=new TextBlock{Text=ex.Message,Foreground=Brush("Danger")};}}};
    }
    async Task ShowInventory(){await ShowGrid("موجودی و انبار","۶۰ رکورد نخست در شروع؛ ادامه فقط با درخواست شما",()=>GetCachedOrLoad("inventory",()=>api.Inventory(0,60)));}
    async Task ShowInvoices(){if(string.IsNullOrWhiteSpace(shmo)){ShowInfo("برای نمایش فاکتورها باید کاربر با مشتری مرتبط وارد شده باشد.");return;}await ShowGrid("فاکتورها و مطالبات","فاکتورهای مشتری جاری",()=>api.Invoices(shmo!));}
    async Task ShowChecks(){await ShowGrid("چک‌ها","۶۰ رکورد نخست؛ بارگذاری مرحله‌ای برای جلوگیری از هنگ",()=>GetCachedOrLoad("checks",()=>api.Checks(0,60)));}
    async Task ShowGrid(string title,string sub,Func<Task<JsonElement>> loader){var root=Page(title,sub);var status=new TextBlock{Text="در حال دریافت اولین بسته…",Foreground=Brush("Muted"),Margin=new Thickness(0,14,0,10)};root.Children.Add(status);var g=DataGridFor();root.Children.Add(g);var more=new Button{Content="＋  دریافت ۶۰ رکورد بعدی",HorizontalAlignment=HorizontalAlignment.Left,Padding=new Thickness(18,10,18,10),Margin=new Thickness(0,0,0,12)};root.Children.Add(more);ContentHost.Children.Add(root);currentReport=ToTable(await loader());g.ItemsSource=currentReport.DefaultView;status.Text=$"{currentReport.Rows.Count:N0} رکورد آماده • READ ONLY";more.Click+=async(s,e)=>{try{more.IsEnabled=false;JsonElement next=title=="موجودی و انبار"?await api.Inventory(currentReport.Rows.Count,60):title=="چک‌ها"?await api.Checks(currentReport.Rows.Count,60):await loader();var nt=ToTable(next);AppendTable(currentReport,nt);status.Text=$"{currentReport.Rows.Count:N0} رکورد آماده • READ ONLY";}catch(Exception ex){ShowError(ex);}finally{more.IsEnabled=true;}};AddFooter(root);}
    async Task ShowAlerts(){currentSection="Alerts"; SetActive("Alerts");var root=Page("مرکز هشدار هوشمند","Attention Center • اولویت‌بندی بر اساس داده واقعی آتیران");var wrap=new WrapPanel();root.Children.Add(wrap);int overdue=0,unpaidCount=0;decimal unpaid=0;try{var c=await api.Checks(0,60);overdue=CountOverdue(c);}catch{}if(!string.IsNullOrWhiteSpace(shmo))try{var u=await api.NotPaid(shmo!);unpaidCount=ArrayCount(u);unpaid=MoneySum(u,"AllFel","MabDaryaftFactor","Tdf");}catch{}wrap.Children.Add(AlertCard("⚠","چک‌های سررسید گذشته",overdue.ToString("N0"),overdue>0));wrap.Children.Add(AlertCard("◈","مطالبات باز",unpaid.ToString("N0"),unpaid>0));wrap.Children.Add(AlertCard("●","تعداد فاکتورهای باز",unpaidCount.ToString("N0"),unpaidCount>0));var detail=Glass("منطق هشدار");((StackPanel)detail.Child).Children.Add(new TextBlock{Text="این مرکز از داده‌های واقعی چک‌ها و فاکتورهای پرداخت‌نشده استفاده می‌کند. هیچ عدد نمونه‌ای تولید نمی‌شود.",TextWrapping=TextWrapping.Wrap,Foreground=Brush("Muted")});root.Children.Add(detail);AddFooter(root);ContentHost.Children.Add(root);}
    void ShowNotifications(){currentSection="Notifications"; SetActive("Notifications");var root=Page("Notification Center","مرکز اعلان • رویدادهای مهم و وضعیت سرویس اعلان");var c=Glass("وضعیت کانال‌ها");var p=(StackPanel)c.Child;p.Children.Add(StatusLine("Local Windows Notification","فعال"));p.Children.Add(StatusLine("Smart Alerts","متصل به Atiran"));p.Children.Add(StatusLine("Remote Push Gateway","آماده اتصال / نیازمند آدرس Gateway"));p.Children.Add(new TextBlock{Text="برای Push واقعی از سرور، آدرس Gateway در تنظیمات ثبت می‌شود. برنامه از رمز عبور SQL یا اتصال مستقیم SQL استفاده نمی‌کند.",Foreground=Brush("Muted"),TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,12,0,0)});root.Children.Add(c);var b=new Button{Content="ارسال اعلان آزمایشی ویندوز"};b.Click+=(s,e)=>Notify("M•R","اعلان آزمایشی Notification Center دریافت شد.");root.Children.Add(b);AddFooter(root);ContentHost.Children.Add(root);}
    void ShowReportBuilder(){currentSection="ReportBuilder"; SetActive("ReportBuilder");var root=Page("Report Studio","ساخت گزارش اختصاصی با فیلتر، عنوان سفارشی و خروجی مدیریتی");var controls=new WrapPanel();var type=new ComboBox{Width=190};foreach(var x in new[]{"مشتریان","کالاها","موجودی","چک‌ها","مطالبات"})type.Items.Add(x);type.SelectedIndex=0;controls.Children.Add(type);var filter=new TextBox{Width=260,Height=38};filter.SetValue(FrameworkElement.ToolTipProperty,"فیلتر متنی");controls.Children.Add(filter);var title=new TextBox{Width=300,Height=38};title.Text="گزارش مدیریتی M•R";controls.Children.Add(title);var load=new Button{Content="پیش‌نمایش"};controls.Children.Add(load);var pdf=new Button{Content="PDF / چاپ"};var excel=new Button{Content="Excel CSV"};var word=new Button{Content="Word HTML"};controls.Children.Add(pdf);controls.Children.Add(excel);controls.Children.Add(word);root.Children.Add(controls);var preview=DataGridFor();root.Children.Add(preview);var summary=Glass("Executive Summary");root.Children.Add(summary);ContentHost.Children.Add(root);load.Click+=async(s,e)=>{try{JsonElement data=type.SelectedIndex switch{0=>await api.Customers(0,60),1=>await api.Kalas(0,60),2=>await api.Inventory(0,60),3=>await api.Checks(0,60),4=>string.IsNullOrWhiteSpace(shmo)?default:await api.NotPaid(shmo!),_=>default};currentReport=ToTable(data);ApplyFilter(currentReport,filter.Text);preview.ItemsSource=currentReport.DefaultView;((StackPanel)summary.Child).Children.Add(new TextBlock{Text=$"{title.Text}\nتعداد رکورد: {currentReport.Rows.Count:N0}\nزمان تولید: {DateTime.Now:yyyy/MM/dd HH:mm}",Foreground=Brush("Text"),FontSize=15});}catch(Exception ex){ShowError(ex);}};excel.Click+=(s,e)=>ExportCsv(currentReport,title.Text);word.Click+=(s,e)=>ExportHtml(currentReport,title.Text);pdf.Click+=(s,e)=>PrintReport(currentReport,title.Text);AddFooter(root);}
    async Task ShowCompany(){currentSection="Company"; SetActive("Company");var root=Page("اطلاعات شرکت","اطلاعات پایه از سرویس آتیران");root.Children.Add(BuildTable(await api.CompanyInfo()));AddFooter(root);ContentHost.Children.Add(root);}
    void ShowSettings(){currentSection="Settings"; SetActive("Settings");var root=Page("تنظیمات و اتصال","هویت بصری، اعلان‌ها و اطلاعات اتصال");var theme=Glass("چهار شخصیت بصری");var p=(StackPanel)theme.Child;foreach(var t in new[]{"Obsidian Neon","Milano Royale","Pearl Azure","Ivory Sage"}){var b=new Button{Content=t};b.Click+=(s,e)=>ApplyTheme(t);p.Children.Add(b);}root.Children.Add(theme);var n=Glass("اعلان و Push");var np=(StackPanel)n.Child;np.Children.Add(new TextBlock{Text="اعلان محلی ویندوز: فعال",Foreground=Brush("Success")});np.Children.Add(new TextBlock{Text="Remote Push: زیرساخت آماده است؛ برای Push سروری باید Gateway آتیران/سرور شما در تنظیمات قرار گیرد.",Foreground=Brush("Muted"),TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,0)});root.Children.Add(n);AddFooter(root);ContentHost.Children.Add(root);}
    async Task PollAlerts(){try{if(!string.IsNullOrWhiteSpace(shmo)){var u=await api.NotPaid(shmo!);var n=ArrayCount(u);if(n>0)tray.BalloonTipText=$"{n:N0} مورد پرداخت‌نشده در حساب جاری";} }catch{} }
    void QuickNotify_Click(object s,RoutedEventArgs e){Notify("M•R","Notification Center آماده است. برای هشدارهای واقعی از مرکز هشدار استفاده کنید.");}
    void Notify(string title,string text){tray.BalloonTipTitle=title;tray.BalloonTipText=text;tray.ShowBalloonTip(3500);}
    void Logout_Click(object s,RoutedEventArgs e){new LoginWindow().Show();Close();}
    StackPanel Page(string title,string subtitle){ContentHost.Children.Clear();var p=new StackPanel{Margin=new Thickness(4)};p.Children.Add(new TextBlock{Text=title,FontSize=30,FontWeight=FontWeights.Bold,Foreground=Brush("Text")});p.Children.Add(new TextBlock{Text=subtitle,FontSize=12,Foreground=Brush("Muted"),Margin=new Thickness(0,4,0,4)});return p;}
    Border Glass(string title){var b=new Border{Background=Brush("Panel"),BorderBrush=Brush("Line"),BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(20),Padding=new Thickness(18),Margin=new Thickness(0,0,0,14)};var p=new StackPanel();p.Children.Add(new TextBlock{Text=title,FontSize=15,FontWeight=FontWeights.SemiBold,Foreground=Brush("Text"),Margin=new Thickness(0,0,0,12)});b.Child=p;return b;}
    Border Metric(string a,string b,string i,string hex){var br=new Border{Background=Brush("Panel"),BorderBrush=Brush("Line"),BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(20),Padding=new Thickness(18),Margin=new Thickness(5)};var p=new StackPanel();p.Children.Add(new TextBlock{Text=i,FontSize=28,Foreground=(Brush)new BrushConverter().ConvertFromString(hex)!});p.Children.Add(new TextBlock{Text=a,Foreground=Brush("Muted"),Margin=new Thickness(0,8,0,2)});p.Children.Add(new TextBlock{Text=b,FontSize=22,FontWeight=FontWeights.Bold,Foreground=Brush("Text")});br.Child=p;return br;}
    Border AlertCard(string icon,string title,string value,bool hot){var b=Metric(title,value,icon,hot?"#FF7C96":"#7BE0AE");b.Width=240;b.Margin=new Thickness(5);return b;}
    Border StatusLine(string a,string b){var br=new Border{Background=Brush("Panel2"),CornerRadius=new CornerRadius(12),Padding=new Thickness(12),Margin=new Thickness(0,0,0,8)};var g=new Grid();g.Children.Add(new TextBlock{Text=a,Foreground=Brush("Text")});g.Children.Add(new TextBlock{Text=b,Foreground=Brush("Success"),HorizontalAlignment=HorizontalAlignment.Left});br.Child=g;return br;}
    DataGrid DataGridFor()=>new(){IsReadOnly=true,AutoGenerateColumns=true,CanUserAddRows=false,CanUserDeleteRows=false,CanUserResizeRows=false,MinHeight=420,Margin=new Thickness(0,10,0,14),FontSize=12};
    DataGrid BuildTable(JsonElement data){var g=DataGridFor();var t=ToTable(data);g.ItemsSource=t.DefaultView;return g;}
    void AppendTable(DataTable target, DataTable source)
    {
        foreach(DataColumn c in source.Columns) if(!target.Columns.Contains(c.ColumnName)) target.Columns.Add(c.ColumnName);
        foreach(DataRow r in source.Rows){var nr=target.NewRow();foreach(DataColumn c in source.Columns)nr[c.ColumnName]=r[c];target.Rows.Add(nr);}
        target.AcceptChanges();
    }
    DataTable ToTable(JsonElement e){var t=new DataTable();if(e.ValueKind!=JsonValueKind.Array)return t;var rows=e.EnumerateArray().ToList();var keys=rows.SelectMany(r=>r.ValueKind==JsonValueKind.Object?r.EnumerateObject().Select(x=>x.Name):Enumerable.Empty<string>()).Distinct().ToList();foreach(var k in keys)t.Columns.Add(k);foreach(var r in rows){var dr=t.NewRow();foreach(var k in keys)if(r.TryGetProperty(k,out var v))dr[k]=v.ValueKind==JsonValueKind.Null?DBNull.Value:v.ToString();t.Rows.Add(dr);}return t;}
    string Scalar(JsonElement e){if(e.ValueKind==JsonValueKind.Number||e.ValueKind==JsonValueKind.String)return e.ToString();if(e.ValueKind==JsonValueKind.Object){foreach(var k in new[]{"Count","count","Result","result","Value","value"})if(e.TryGetProperty(k,out var v))return v.ToString();}return e.ValueKind==JsonValueKind.Array?e.GetArrayLength().ToString():"—";}
    int ArrayCount(JsonElement e)=>e.ValueKind==JsonValueKind.Array?e.GetArrayLength():0;
    decimal MoneySum(JsonElement e,params string[] fields){decimal s=0;if(e.ValueKind!=JsonValueKind.Array)return s;foreach(var r in e.EnumerateArray()){decimal all=0,paid=0;decimal.TryParse(Get(r,fields.ElementAtOrDefault(0)??""),NumberStyles.Any,CultureInfo.InvariantCulture,out all);decimal.TryParse(Get(r,fields.ElementAtOrDefault(1)??""),NumberStyles.Any,CultureInfo.InvariantCulture,out paid);s+=all-paid;}return s;}
    int CountOverdue(JsonElement e){if(e.ValueKind!=JsonValueKind.Array)return 0;var now=DateTime.Now.Date;int n=0;foreach(var r in e.EnumerateArray()){var d=Get(r,"SarDate","sarDate","Date","date");if(DateTime.TryParse(d,out var dt)&&dt.Date<now)n++;}return n;}
    string? Get(JsonElement e,params string[] properties){
        foreach(var p in properties){
            if(e.TryGetProperty(p,out var v)) return v.ToString();
        }
        return null;
    }
    static System.Drawing.Icon? CreateTrayIcon(){
        try{
            var exe=Environment.ProcessPath;
            return !string.IsNullOrWhiteSpace(exe) && File.Exists(exe) ? System.Drawing.Icon.ExtractAssociatedIcon(exe) : null;
        }catch{return null;}
    }
    string? GetRow(DataRow r,params string[] names){foreach(var n in names)if(r.Table.Columns.Contains(n)&&r[n]!=DBNull.Value)return r[n]?.ToString();return null;}
    void ApplyFilter(DataTable t,string q){q=q.Replace("'","''");t.DefaultView.RowFilter=string.IsNullOrWhiteSpace(q)?"":string.Join(" OR ",t.Columns.Cast<DataColumn>().Where(c=>c.DataType==typeof(string)).Select(c=>$"[{c.ColumnName}] LIKE '%{q}%'").DefaultIfEmpty("1=0"));}
    void ExportCsv(DataTable? t,string title){if(t==null)return;var d=new Microsoft.Win32.SaveFileDialog{Filter="Excel CSV|*.csv",FileName="MReport_Report.csv"};if(d.ShowDialog()!=true)return;var sb=new StringBuilder();sb.AppendLine(string.Join(",",t.Columns.Cast<DataColumn>().Select(c=>Csv(c.ColumnName))));foreach(DataRow r in t.Rows)sb.AppendLine(string.Join(",",t.Columns.Cast<DataColumn>().Select(c=>Csv(r[c]?.ToString()??""))));File.WriteAllText(d.FileName,"\uFEFF"+sb);Notify("M•R","فایل Excel-compatible ذخیره شد.");}
    void ExportHtml(DataTable? t,string title){if(t==null)return;var d=new Microsoft.Win32.SaveFileDialog{Filter="Word-compatible HTML|*.html",FileName="MReport_Report.html"};if(d.ShowDialog()!=true)return;var sb=new StringBuilder($"<html dir='rtl'><meta charset='utf-8'><body style='font-family:Tahoma;background:#fff'><h1>M•R</h1><h2>{System.Net.WebUtility.HtmlEncode(title)}</h2><table border='1' cellpadding='6' cellspacing='0'>");sb.Append("<tr>");foreach(DataColumn c in t.Columns)sb.Append("<th>"+System.Net.WebUtility.HtmlEncode(c.ColumnName)+"</th>");sb.Append("</tr>");foreach(DataRow r in t.Rows){sb.Append("<tr>");foreach(DataColumn c in t.Columns)sb.Append("<td>"+System.Net.WebUtility.HtmlEncode(r[c]?.ToString()??"")+"</td>");sb.Append("</tr>");}sb.Append("</table><hr><footer>Meelano Studio Design • Milad Yaghoobi • M•R • Read Only</footer></body></html>");File.WriteAllText(d.FileName,sb.ToString(),Encoding.UTF8);Notify("M•R","فایل Word-compatible ذخیره شد.");}
    void PrintReport(DataTable? t,string title){if(t==null)return;var doc=new FlowDocument{FontFamily=new FontFamily("Segoe UI"),PagePadding=new Thickness(40)};doc.Blocks.Add(new Paragraph(new Run("M•R • Meelano Studio Design")){FontSize=20,FontWeight=FontWeights.Bold});doc.Blocks.Add(new Paragraph(new Run(title)));var table=new System.Windows.Documents.Table();foreach(DataColumn c in t.Columns)table.Columns.Add(new System.Windows.Documents.TableColumn());var rg=new System.Windows.Documents.TableRowGroup();var h=new System.Windows.Documents.TableRow();foreach(DataColumn c in t.Columns)h.Cells.Add(new System.Windows.Documents.TableCell(new Paragraph(new Run(c.ColumnName))));rg.Rows.Add(h);foreach(DataRow r in t.Rows){var tr=new System.Windows.Documents.TableRow();foreach(DataColumn c in t.Columns)tr.Cells.Add(new System.Windows.Documents.TableCell(new Paragraph(new Run(r[c]?.ToString()??""))));rg.Rows.Add(tr);}table.RowGroups.Add(rg);doc.Blocks.Add(table);var paginator=((System.Windows.Documents.IDocumentPaginatorSource)doc).DocumentPaginator;var pd=new System.Windows.Controls.PrintDialog();if(pd.ShowDialog()==true)pd.PrintDocument(paginator,"M•R");}
    string Csv(string s)=>"\""+s.Replace("\"","\"\"")+"\"";
    void AddFooter(StackPanel p){p.Children.Add(new Border{Margin=new Thickness(0,12,0,24),Padding=new Thickness(10),Background=Brush("Panel2"),CornerRadius=new CornerRadius(14),Child=new TextBlock{Text="M•R  •  Meelano Studio Design  •  طراحی و توسعه: Milad Yaghoobi  •  READ ONLY",Foreground=Brush("Muted"),HorizontalAlignment=HorizontalAlignment.Center}});}
    Brush Brush(string key)=> (Brush)FindResource(key);
    static string? ReadSetting(string key){try{var f=Path.Combine(AppContext.BaseDirectory,"mreport.settings.json");if(!File.Exists(f))return null;using var d=JsonDocument.Parse(File.ReadAllText(f));return d.RootElement.TryGetProperty(key,out var v)?v.ToString():null;}catch{return null;}}
    void ShowInfo(string t){ContentHost.Children.Clear();ContentHost.Children.Add(new TextBlock{Text=t,Foreground=Brush("Text"),FontSize=22,Margin=new Thickness(12),TextWrapping=TextWrapping.Wrap});}
    void ShowError(Exception ex){ShowInfo("خطا در دریافت اطلاعات واقعی از SQL Server آتیران:\n"+ex.Message);ConnectionText.Text="● SQL CONNECTION ERROR";ConnectionText.Foreground=Brush("Danger");}
    void ApplyTheme(string theme){currentTheme=theme;var dict=(System.Collections.Generic.Dictionary<string,string>)new(){["Obsidian Neon"]=("#080B12|#111722|#A78BFA|#67E8F9"),["Milano Royale"]=("#0C0A08|#19130D|#D8B36A|#F4E4BE"),["Pearl Azure"]=("#F4F7FB|#FFFFFF|#2F6BFF|#0EA5E9"),["Ivory Sage"]=("#F4F1E8|#FFFDF7|#557C62|#B68B4C")};var parts=dict[theme].Split('|');System.Windows.Application.Current.Resources["Bg"]=new SolidColorBrush((Color)ColorConverter.ConvertFromString(parts[0]));System.Windows.Application.Current.Resources["Panel"]=new SolidColorBrush((Color)ColorConverter.ConvertFromString(parts[1]));System.Windows.Application.Current.Resources["Accent"]=new SolidColorBrush((Color)ColorConverter.ConvertFromString(parts[2]));System.Windows.Application.Current.Resources["Accent2"]=new SolidColorBrush((Color)ColorConverter.ConvertFromString(parts[3]));
        var light=theme is "Pearl Azure" or "Ivory Sage"; System.Windows.Application.Current.Resources["Text"]=new SolidColorBrush((Color)ColorConverter.ConvertFromString(light?"#17202C":"#F4F7FB")); System.Windows.Application.Current.Resources["Muted"]=new SolidColorBrush((Color)ColorConverter.ConvertFromString(light?"#5D6A7D":"#98A5BA")); System.Windows.Application.Current.Resources["Line"]=new SolidColorBrush((Color)ColorConverter.ConvertFromString(light?"#D7DEE8":"#273246")); Background=Brush("Bg");}
}

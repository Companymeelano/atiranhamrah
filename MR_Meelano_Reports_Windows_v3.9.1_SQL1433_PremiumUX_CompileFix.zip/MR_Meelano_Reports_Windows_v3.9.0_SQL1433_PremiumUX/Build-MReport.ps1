$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$proj = Join-Path $PSScriptRoot 'MReport.Windows.csproj'
$publish = Join-Path $PSScriptRoot 'bin\Release\net8.0-windows\win-x64\publish'

Write-Host 'M•R — Meelano Reports 3.5.3' -ForegroundColor Cyan
Write-Host 'Clean → Restore → Build → Publish' -ForegroundColor DarkCyan

if (Test-Path (Join-Path $PSScriptRoot 'bin')) { Remove-Item (Join-Path $PSScriptRoot 'bin') -Recurse -Force }
if (Test-Path (Join-Path $PSScriptRoot 'obj')) { Remove-Item (Join-Path $PSScriptRoot 'obj') -Recurse -Force }

dotnet restore $proj
if ($LASTEXITCODE -ne 0) { throw "dotnet restore failed with exit code $LASTEXITCODE" }

dotnet build $proj -c Release --no-restore
if ($LASTEXITCODE -ne 0) { throw "dotnet build failed with exit code $LASTEXITCODE" }

dotnet publish $proj -c Release -r win-x64 --self-contained true --no-restore -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o $publish
if ($LASTEXITCODE -ne 0) { throw "dotnet publish failed with exit code $LASTEXITCODE" }

$exe = Join-Path $publish 'MR.exe'
if (-not (Test-Path $exe)) { throw "Publish finished without MR.exe" }

Write-Host "SUCCESS — Build + Publish completed: $exe" -ForegroundColor Green
Write-Host 'Installer: compile Installer.iss with Inno Setup 6.' -ForegroundColor Yellow

using System.Windows;
using System.Windows.Media.Animation;

namespace MReport.Windows;

public partial class LoadingWindow : Window
{
    public LoadingWindow(){InitializeComponent();}
    public async Task WarmUpAsync(AtiranApiClient api)
    {
        var jobs = new (string stage,string detail,Func<Task> work)[]
        {
            ("اتصال به هسته داده", "بررسی نشست SQL Server و آماده‌سازی Pool اتصال", () => api.TestConnectionAsync()),
            ("آماده‌سازی مشتریان", "نمونه اولیه ۶۰ رکورد برای شروع سریع رابط", async () => await MReportCache.SetAsync("customers", await api.Customers(0,60))),
            ("آماده‌سازی کالاها", "نمونه اولیه ۶۰ رکورد برای جستجوی فوری", async () => await MReportCache.SetAsync("goods", await api.Kalas(0,60))),
            ("آماده‌سازی موجودی", "نمونه اولیه ۶۰ رکورد بدون بارگذاری کل دیتابیس", async () => await MReportCache.SetAsync("inventory", await api.Inventory(0,60))),
            ("آماده‌سازی چک‌ها", "نمونه اولیه ۶۰ رکورد برای نمایش سریع", async () => await MReportCache.SetAsync("checks", await api.Checks(0,60))),
            ("آماده‌سازی داشبورد", "شاخص‌های مدیریتی بعداً به‌صورت Lazy بارگذاری می‌شوند", async () => { await api.CountKa(); await api.CountMo(); })
        };
        for(int i=0;i<jobs.Length;i++)
        {
            var job=jobs[i]; StageText.Text=job.stage; DetailText.Text=job.detail;
            var basePct=(i*100.0)/jobs.Length; AnimateProgress(basePct);
            await Task.Run(job.work);
            AnimateProgress(((i+1)*100.0)/jobs.Length);
            await Task.Delay(160);
        }
        StageText.Text="محیط تحلیلی آماده است"; DetailText.Text="داده‌های اولیه در حافظه آماده‌اند؛ ادامه بارگذاری فقط هنگام نیاز انجام می‌شود."; AnimateProgress(100); await Task.Delay(450);
    }
    void AnimateProgress(double percent)
    {
        var target=Math.Max(0,Math.Min(100,percent));
        var anim=new DoubleAnimation(ProgressFill.Width,target*6.5,TimeSpan.FromMilliseconds(280)){EasingFunction=new QuadraticEase{EasingMode=EasingMode.EaseOut}};
        ProgressFill.BeginAnimation(WidthProperty,anim); PercentText.Text=$"{target:0}%";
    }
}
